function mudar(element) {
    let txt = element.value;
    document.getElementById('copy').innerHTML = txt;
}

function clicar() {
    alert('Você clicou aqui!');
}

function carregar() {
    alert('Olá! A página acabou de carregar =)')
}