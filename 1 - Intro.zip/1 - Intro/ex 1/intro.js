
/**
 * Alerta com a mensagem "Hello world"
 */
function hello() {
    alert('Hello world!');
}

//Este texto é um comentário. Esta parte não é entendida como código

/**
 * Este é um comentário com  múltiplas linhas.
 * 
 * Quando há um comentário deste tipo acima de uma função (function), 
 * ele é identificado pelo editor de código como docstring.
 */