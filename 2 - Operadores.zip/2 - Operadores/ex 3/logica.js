
let a = true, b = false, c = true;

console.log(a && c); //true

console.log(a && b); //false

console.log(a || b); //true

console.log(!a); //false

console.log(!b); //true

console.log(2 < 3 + 2 && 2 < 4) //true
// 2 é menor que 5 E 2 é menor que 4, então é verdadeiro