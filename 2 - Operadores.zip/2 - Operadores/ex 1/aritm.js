function calc(a,b) {
    let result;

    result = a+b;
    alert('Soma: '+result);

    result = a-b;
    alert('Subtração: '+result);

    result = a*b;
    alert('Multiplicação: '+result);

    result = a/b;
    alert('Divisão: '+result);

    result = a%b;
    alert('Resto da divisão: '+result);
}
