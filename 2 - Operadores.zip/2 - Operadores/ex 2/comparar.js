function comparar(a,b) {
    alert('A igual a B: ', a==b);
    alert('A diferente de B: ', a!=b);
    alert('A maior que B: ', a>b);
    alert('A menor que B: ', a<b);
    alert('A maior ou igual a B: ', a>=b);
    alert('A menor ou igual a B: ', a<=b);
}